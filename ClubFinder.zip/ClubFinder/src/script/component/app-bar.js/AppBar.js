class AppBar extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = ` <h2>Club Finder</h2>`;
    }

}
costumElement.define("app-bar", AppBar);